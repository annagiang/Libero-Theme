<?php

function libero_get_template_part( $slug, $name = '' ) {
    $template = '';
	$template_path = "template-parts/";
	$plugin_path = LIBERO_PLUGIN_DIR . "/templates/";

    // Look in yourtheme/slug-name.php and yourtheme/template-parts/slug-name.php
    if ( $name ) {
        $template = locate_template( array( "{$slug}-{$name}.php", $template_path . "{$slug}-{$name}.php" ) );
    }

    // Get default slug-name.php
    if ( ! $template && $name && file_exists( $plugin_path . "{$slug}-{$name}.php" ) ) {
        $template = $plugin_path . "{$slug}-{$name}.php";
    }

    // If template file doesn't exist, look in yourtheme/slug.php and yourtheme/template-parts/slug.php
    if ( ! $template ) {
        $template = locate_template( array( "{$slug}.php", $template_path . "{$slug}.php" ) );
    }
	
	 // Get default slug.php
	if ( ! $template && file_exists( $plugin_path . "{$slug}.php" ) ) {
        $template = $plugin_path . "{$slug}.php";
    }
	
    if ( $template ) {
        load_template( $template, false );
    }
}

function libero_get_categories_ids($slug) {
	$str = '';
	$term = array();
	$array_slug = explode(',',$slug);
	if( is_array($array_slug) ) {
		foreach($array_slug as $item) {
			if( is_object(get_term_by('slug', $item, 'category')) ) {
				$term[] = get_term_by('slug', $item, 'category')->term_id;
			}
		}
	}
	return implode(",",$term);
}

function libero_render_script_ajax_block($template, $libero_attr, $liberokey) {
	ob_start();
	?>
	<script type="text/javascript">
		var libero_<?php echo esc_html($liberokey) ?> = new libero_blocks();
		libero_<?php echo esc_html($liberokey) ?>.atts = '<?php echo json_encode($libero_attr) ?>';
		libero_<?php echo esc_html($liberokey) ?>.template = '<?php echo $template ?>'; 
	</script>
	<?php
	echo ob_get_clean();
}

function libero_render_categories($libero_attr, $liberokey, $is_ajax = true) {
	ob_start();
	$class_ajax = '';
	if( $is_ajax ) $class_ajax = 'class="libero_subcat_ajax"';
	if( isset($libero_attr['categories']) && !empty($libero_attr['categories']) && libero_get_categories_ids($libero_attr['categories']) ) {
		$categories = get_categories( array('include' => libero_get_categories_ids($libero_attr['categories']), 'hide_empty' => 1, 'orderby' => 'term_group' ) );
		if( sizeof($categories) == 1 ) {
			$categories = get_categories( array('parent' => libero_get_categories_ids($libero_attr['categories']), 'hide_empty' => 1, 'orderby' => 'term_group' ) );
		}
		if( sizeof($categories) > 1 ) {
	?>
	<ul class="breadcrumb">
		<li class="active"><a <?php echo $class_ajax ?> href="#"><?php esc_html_e('All','libero') ?></a></li>
		<?php foreach( $categories as $category ) { ?>
		<li><a <?php echo $class_ajax ?> href="<?php echo esc_url(get_category_link( $category->term_id )) ?>"  data-key="libero_<?php echo esc_html($liberokey) ?>" data-term="<?php echo esc_attr($category->slug) ?>"><?php echo $category->name ?></a></li>
		<?php } ?>
	</ul>
	<?php
		}
	}
	echo ob_get_clean();
}

function libero_paging_nav($the_query = '',$libero_attr = array(),$liberokey = '') {
	global $paged, $wp_query;
	ob_start();
	if( !isset($the_query) || empty($the_query) ) $the_query = $wp_query;
	if( !isset( $libero_attr['pagenavi'] ) ) $libero_attr['pagenavi'] = 'number';
	if( $libero_attr['pagenavi'] == 'number' ) {
		$tf_big = 999999999;
		$my_page = max( get_query_var('paged'), get_query_var('page') );
		$tf_paginate_links = paginate_links( array(
			'base' => str_replace( $tf_big, '%#%', esc_url( get_pagenum_link( $tf_big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, $my_page ),
			'total' => $the_query->max_num_pages,
			'prev_text'    => __('&#171; Previous','libero'),
			'next_text'    => __('Next &#187;','libero'),
			'type'			=> 'array'
		 ));
		
		if( is_array( $tf_paginate_links ) ) {
			$paged = ( $my_page == 0 ) ? 1 : $my_page;
	?>
			<div class="libero-pagenavi">
				<?php foreach ( $tf_paginate_links as $page ) echo $page; ?>
			</div>
	<?php
		}
	}
	
	if( $libero_attr['pagenavi'] == 'next_prev' ) {
		if ( $the_query->max_num_pages > 1 ) :  ?>
		<nav class="row navigation" role="navigation">
			<div class="col-sm-6 nav-previous"><?php previous_posts_link( '<i class="fa fa-angle-double-left"></i> Prev Page', $the_query ->max_num_pages ); ?></div>
			<div class="col-sm-6 nav-next"><?php next_posts_link( 'Next Page <i class="fa fa-angle-double-right"></i>', $the_query ->max_num_pages ); ?></div>
		</nav>
		<?php endif;
	}
	
	if( $libero_attr['pagenavi'] == 'load_more' ) {
		$is_pages = $the_query->found_posts - $libero_attr['number'];
		$max_pages = $is_pages > 0 ? max(ceil(( $the_query->found_posts - $libero_attr['number'] ) / $libero_attr['number_loadmore']),2) : 1;
		if( $the_query->max_num_pages > 1 ) {
		?>
			<a href="javascript:;" data-paged="2" data-disable="0" data-count-ajax="0" data-max-paged="<?php echo esc_attr($max_pages) ?>" data-key="libero_<?php echo $liberokey ?>" class="libero_loadmore"><?php esc_html_e('Load more','libero') ?></a>
			
			<?php get_template_part("template-parts/loading") ?>
		<?php
		}
	}
	
	echo ob_get_clean();
}