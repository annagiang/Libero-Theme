function libero_blocks() {
	this.atts = '';
	this.template = '';
}